import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class CardsButtonListener implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		Cards card=new Cards();
	}
}