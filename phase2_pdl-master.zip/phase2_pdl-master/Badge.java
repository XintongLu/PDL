
/**
*Classe Badge
*@author samba-lu
*@version 1.2
*/

   public class Badge {
                         /** 
                          * attribut : numero badge
                          */

	   					  private int ine;

                          /**
                           * getter pour l'attribut numero badge
                           * @return valeur du num�ro du badge
                           */

                            public int getIne() {
                             return ine;
                             }

                            /**
                             * setter pour l'attribut numero badge
                             * @param emplacement :  nouvelle valeur du num�ro du badge
                             */

                              public void setIne (int ine) {
                               this.ine= ine;

                              }
                       }
