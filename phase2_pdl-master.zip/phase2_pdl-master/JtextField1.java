import javax.swing.*;

public class JtextField1 {
	JPanel pannel = new JPanel();
	JTextField testField1 = new JTextField ("admin");
	pannel.add(testField1);
	f.getContentPane().add(pannel);
	f.setVisible(true);
}
