import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Ihm {
 public static void main( String [] args){
	 Fenetre f =new Fenetre();
	// Cards card= new Cards();
	// Confirmation conf=new Confirmation();
	 
 }
}